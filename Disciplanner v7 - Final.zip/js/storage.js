// declara um conjunto inicial de contatos
var db_cadastro_inicial = {
    "data": [
        {
            "id": 1,
            "nome": "conta luz",
            "modalidade": "Contas Fixas (Água, Luz...)",
            "situação": "pendente",
            "fornecedor": "cemig",
            "valor": "240,00",
            "vencimento": "21/06/2020",
            "descricao": "conta de luz"
        },
       
    ]
}

// Caso os dados já estejam no Local Storage, caso contrário, carrega os dados iniciais
var db = JSON.parse(localStorage.getItem('db_cadastro'));
if (!db) {
    db = db_cadastro_inicial
};

// Exibe mensagem em um elemento de ID msg
function displayMessage(msg) {
    $('#msg').html('<div class="alert alert-warning">' + msg + '</div>');
}

function insertCadastro(cadastro) {
    // Calcula novo Id a partir do último código existente no array (PODE GERAR ERRO SE A BASE ESTIVER VAZIA)
    let novoId = db.data[db.data.length - 1].id + 1;
    let novoCadastro   = {
        "id": novoId,
        "nome": cadastro.nome,
        "modalidade" : cadastro.modalidade,
        "situacao": cadastro.situacao,
        "fornecedor" : cadastro.fornecedor,
        "valor": cadastro.valor,
        "vencimento": cadastro.vencimento,
        "descricao": cadastro.descricao
    };

    // Insere o novo objeto no array
    db.data.push(novoCadastro);
    displayMessage("Cadastro inserido com sucesso");

    // Atualiza os dados no Local Storage
    localStorage.setItem('db_cadastro', JSON.stringify(db));
}

function updateCadastro(id, cadastro) {
    // Localiza o indice do objeto a ser alterado no array a partir do seu ID
    let index = db.data.map(obj => obj.id).indexOf(id);

    // Altera os dados do objeto no array
    db.data[index].nome = cadastro.nome,
    db.data[index].modalidade = cadastro.modalidade,
    db.data[index].situacao = cadastro.situacao,
    db.data[index].fornecedor = cadastro.fornecedor,
    db.data[index].valor = cadastro.valor,
    db.data[index].vencimento = cadastro.vencimento,
    db.data[index].descricao = cadastro.descricao

    displayMessage("Cadastro alterado com sucesso");

    // Atualiza os dados no Local Storage
    localStorage.setItem('db_cadastro', JSON.stringify(db));
}

function deleteCadastro(id) {    
    // Filtra o array removendo o elemento com o id passado
    db.data = db.data.filter(function (element) { return element.id != id });

    displayMessage("Cadastro removido com sucesso");

    // Atualiza os dados no Local Storage
    localStorage.setItem('db_cadastro', JSON.stringify(db));
}