var ctx = document.getElementById('myChart2').getContext('2d');

var situacao = ["Quitada", "Pendente"];
					
var dbTeste = JSON.parse(localStorage.getItem("db_cadastro")).data;

var valores = [0.0,0.0];

for (var i = 0; i < dbTeste.length; i++) {
        var cat = dbTeste[i].situacao-1;
        var valorDesp = parseFloat(dbTeste[i].valor.replace(',',','));
        valores[cat] += valorDesp;
}
                      
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        labels: situacao,
        datasets: [{
            label: 'Contas',
            data: valores,
            backgroundColor: [
                'green',
                'yellow'
            ],
            borderColor: [
                'black', 'black', 'black', 'black', 'black', 'black', 'black', 'black', 'black', 'black', 
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                
            ],
            borderWidth: 1
        }]
    },
    layout: {
        padding: {
            left: 0,
            right: 0,
            top: 0,
            bottom: 1,
        }
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});