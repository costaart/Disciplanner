var logado = false;

if (localStorage.getItem("acesso") == "true") {
    logado = true;
    alert("Bem vindo !"+username);
}
