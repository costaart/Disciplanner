var ctx = document.getElementById('myChart').getContext('2d');

var categorias = [	"Moradia", "Contas fixas", "Transporte", "Alimentação", "Supermercado", "Saúde","Vestuário", "Lazer", "Bem estar","Viagem"	];
					
var dbTeste = JSON.parse(localStorage.getItem("db_cadastro")).data;

var valores = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0];

for (var i = 0; i < dbTeste.length; i++) {
        var cat = dbTeste[i].modalidade-1;
        var valorDesp = parseFloat(dbTeste[i].valor.replace(',',','));
        valores[cat] += valorDesp;
}
                      
var myChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: categorias,
        datasets: [{
            label: 'Contas',
            data: valores,
            backgroundColor: [
                'green',
                'yellow',
                'blue',
                'pink',
                'red',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 99, 132, 1)',
                'orange',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderColor: [
                'black', 'black', 'black', 'black', 'black', 'black', 'black', 'black', 'black', 'black', 
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                
            ],
            borderWidth: 1
        }]
    },
    layout: {
        padding: {
            left: 0,
            right: 0,
            top: 0,
            bottom: 1,
        }
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});