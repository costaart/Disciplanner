function init() {
   // Adiciona funções para tratar os eventos 
   $("#btnInsertt").click(function () {
    // Verfica se o formulário está preenchido corretamente
    if (!$('#form-cadastro')[0].checkValidity()) {
        displayMessage("Preencha o formulário corretamente.");
        return;
    }
    // Obtem os valores dos campos do formulário
    
    let campoModality = $("#modality").val();
    let campoNome = $("#name").val();
    let campoSituation = $('#situation').val();
    let campoForn = $("#forn").val();
    let campoValor = $('#value_cont').val();
    let campoDate = $('#date').val();
    let campoDesc = $('#desc').val();
    let cadastro = { nome: campoNome, 
        modalidade: campoModality, 
        situacao: campoSituation, 
        fornecedor: campoForn, 
        valor: campoValor,
        vencimento: campoDate,
        descricao: campoDesc  };

    insertCadastro(cadastro);
    exibeCadastro();

});
} 
